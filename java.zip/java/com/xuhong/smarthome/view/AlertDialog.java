package com.xuhong.smarthome.view;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;

/**
 * Created by xuhong on 2017/8/28.
 */

public class AlertDialog extends android.support.v7.app.AlertDialog {


    public AlertDialog(Context context) {
        super(context);


    }


}
