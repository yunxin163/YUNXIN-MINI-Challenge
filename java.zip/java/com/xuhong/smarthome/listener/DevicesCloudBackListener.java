package com.xuhong.smarthome.listener;

/**
 * Created by xuhong on 2017/8/26.
 */

public interface DevicesCloudBackListener {


}
